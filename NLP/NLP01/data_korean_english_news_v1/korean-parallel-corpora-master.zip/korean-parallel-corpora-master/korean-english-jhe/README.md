JHE evaluation data (dev and eval), see also https://doi.org/10.5281/zenodo.891295
