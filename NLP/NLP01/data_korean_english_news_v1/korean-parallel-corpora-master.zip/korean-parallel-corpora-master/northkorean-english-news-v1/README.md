Kim, Hirasawa and Komachi (2020)  created the North Korean to English translation evaluation dataset by having a North Korean native speaker manually convert the evaluation dataset in the News Korean-English parallel corpus into North Korean grammar.

Kim, H., Hirasawa, T., & Komachi, M. (2020). Zero-shot North Korean to English Neural Machine Translation by Character Tokenization and Phoneme Decomposition. *Proceedings of the 58th Annual Meeting of the Association for Computational Linguistics: Student Research Workshop*, 72–78. https://www.aclweb.org/anthology/2020.acl-srw.11


NOTE: northkorean-english.[dev|test].en are the exact same as korean-english-park.[dev|test].en in korean-english-news-v1
