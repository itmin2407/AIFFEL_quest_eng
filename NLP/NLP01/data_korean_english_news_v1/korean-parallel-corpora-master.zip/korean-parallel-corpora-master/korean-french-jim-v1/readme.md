For more details, see https://sites.google.com/site/koreanparalleldata/

(c) jungyeul.park@gmail.com
