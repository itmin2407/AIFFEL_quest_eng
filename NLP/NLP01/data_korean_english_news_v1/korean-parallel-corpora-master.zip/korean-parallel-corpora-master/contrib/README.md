Korean Parallel corpora (of https://sites.google.com/site/koreanparalleldata/) 

See also JHE evaluation data (dev and eval), available at https://doi.org/10.5281/zenodo.891295

Korean Parallel corpora are made available under the terms of the Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)


Please post any questions about the corpus to jungyeul.park (AT) gmail.com
